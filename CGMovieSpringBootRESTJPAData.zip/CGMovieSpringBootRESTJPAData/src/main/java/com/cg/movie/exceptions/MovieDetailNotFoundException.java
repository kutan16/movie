package com.cg.movie.exceptions;

public class MovieDetailNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
