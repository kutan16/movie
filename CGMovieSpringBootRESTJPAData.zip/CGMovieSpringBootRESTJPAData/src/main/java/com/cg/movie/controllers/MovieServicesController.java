package com.cg.movie.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class MovieServicesController {

	
}
