package com.cg.movie.beans;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Song {
	private String songName;
	private int songId;
	private String artishName;
	@ManyToOne
	public Movie movie;
	public Song() {
		super();
	}
	public Song(String songName, int songId, String artishName, Movie movie) {
		super();
		this.songName = songName;
		this.songId = songId;
		this.artishName = artishName;
		this.movie = movie;
	}
	public Song(String songName, int songId, String artishName) {
		super();
		this.songName = songName;
		this.songId = songId;
		this.artishName = artishName;
	}
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}
	public int getSongId() {
		return songId;
	}
	public void setSongId(int songId) {
		this.songId = songId;
	}
	public String getArtishName() {
		return artishName;
	}
	public void setArtishName(String artishName) {
		this.artishName = artishName;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((artishName == null) ? 0 : artishName.hashCode());
		result = prime * result + ((movie == null) ? 0 : movie.hashCode());
		result = prime * result + songId;
		result = prime * result + ((songName == null) ? 0 : songName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Song other = (Song) obj;
		if (artishName == null) {
			if (other.artishName != null)
				return false;
		} else if (!artishName.equals(other.artishName))
			return false;
		if (movie == null) {
			if (other.movie != null)
				return false;
		} else if (!movie.equals(other.movie))
			return false;
		if (songId != other.songId)
			return false;
		if (songName == null) {
			if (other.songName != null)
				return false;
		} else if (!songName.equals(other.songName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Song [songName=" + songName + ", songId=" + songId + ", artishName=" + artishName + "]";
	}
	
}
